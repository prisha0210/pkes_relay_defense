// test_pkes.cpp - Unit tests (no test framework needed).
//
// Build:  g++ -std=c++17 -O2 -Iinclude tests/test_pkes.cpp -o test_pkes
// Run:    ./test_pkes        (Windows: test_pkes.exe)

#include <cmath>
#include <cstdio>
#include <string>

#include "pkes.hpp"

using namespace pkes;

static int passed = 0, failed = 0;

static void check(bool condition, const std::string& name) {
    std::printf("[%s] %s\n", condition ? "PASS" : "FAIL", name.c_str());
    condition ? ++passed : ++failed;
}

static Key16 fixedKey() {
    Key16 k{};
    for (int i = 0; i < 16; ++i) k[i] = static_cast<uint8_t>(i);
    return k;
}

int main() {
    const Key16 SECRET = fixedKey();

    // --- AES-128: official FIPS-197 Appendix C.1 test vector ---
    aes::Block pt = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
    aes::Block expected = {0x69,0xc4,0xe0,0xd8,0x6a,0x7b,0x04,0x30,0xd8,0xcd,0xb7,0x80,0x70,0xb4,0xc5,0x5a};
    check(aes::encrypt(SECRET, pt) == expected, "AES-128 matches FIPS-197 test vector");

    KeyFob owner{SECRET};
    KeyFob ownerLegacy{SECRET}; ownerLegacy.motionAware = false;

    // --- Legacy car: shows the problem ---
    LegacyCar legacy(SECRET);
    check(legacy.tryUnlock(owner, RadioPath::direct(1.0)).unlocked, "Legacy: owner at 1 m unlocks");
    check(!legacy.tryUnlock(owner, RadioPath::direct(20.0)).unlocked, "Legacy: key 20 m away (no relay) refused");
    check(legacy.tryUnlock(ownerLegacy, RadioPath::relayed(0.5, 20, 1.0, 1000)).unlocked,
          "Legacy: RELAY ATTACK SUCCEEDS (the problem)");

    // --- Secure car: shows the solution ---
    SecureCar secure(SECRET, 0);
    check(secure.tryUnlock(owner, RadioPath::direct(1.0)).unlocked, "Secure: owner at 1 m unlocks");

    Decision relay = secure.tryUnlock(owner, RadioPath::relayed(0.5, 20, 1.0, 1000));
    check(!relay.unlocked && relay.measuredDistanceM > 2.0, "Secure: relay attack refused (measured > 2 m)");
    check(!secure.tryUnlock(owner, RadioPath::relayed(0.5, 5, 1.0, 0)).unlocked, "Secure: zero-delay relay refused");

    KeyFob fake{randomBytes<16>()};
    check(!secure.tryUnlock(fake, RadioPath::direct(1.0)).unlocked, "Secure: fake fob with wrong key refused");

    std::optional<Reply> recorded = owner.respond(randomBytes<8>());
    check(!secure.tryUnlock(owner, RadioPath::direct(1.0), recorded).unlocked, "Secure: replayed response refused");

    KeyFob idle{SECRET}; idle.secondsSinceMotion = 3600;
    check(!secure.tryUnlock(idle, RadioPath::relayed(0.5, 15, 1.0, 0)).unlocked, "Secure: sleeping fob cannot be relayed");

    SecureCar monitor(SECRET, 3);
    for (int i = 0; i < 3; ++i) monitor.tryUnlock(owner, RadioPath::relayed(0.5, 20, 1.0, 1000));
    check(monitor.relayAlert(), "Secure: Gateway ECU alert after 3 relay attempts");

    SecureCar pinCar(SECRET, 1, 2.0, 5, true);
    check(!pinCar.tryStart("0000") && pinCar.tryStart("2580"), "Secure: PIN-to-drive blocks wrong PIN");

    SecureCar ranging(SECRET, 5);
    double d = ranging.measureDistance(RadioPath::direct(1.2, 0.05));
    check(std::fabs(d - 1.2) < 0.2, "Secure: UWB distance estimate accurate (1.2 m)");

    std::printf("\n%d passed, %d failed\n", passed, failed);
    return failed == 0 ? 0 : 1;
}
