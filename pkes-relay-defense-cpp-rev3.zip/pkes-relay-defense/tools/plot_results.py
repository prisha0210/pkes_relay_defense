"""
OPTIONAL: draws the two charts in results/ from the CSV files written by the
C++ program monte_carlo. The C++ code does not need this; the charts are
already included in the repository.

Run (from the repository folder):  pip install matplotlib && python tools/plot_results.py
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = Path(__file__).resolve().parent.parent / "results"
BLUE, ORANGE, TEXT, TEXT2 = "#257de0", "#f47230", "#191919", "#666666"


def style(ax):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color("#cccccc")
    ax.tick_params(colors=TEXT2, labelsize=9)
    ax.yaxis.grid(True, color="#eeeeee", linewidth=0.8)
    ax.set_axisbelow(True)


rows = list(csv.DictReader(open(R / "simulation_results.csv")))
sig = ["0.10", "0.30", "0.50"]
single = [float(r["percent"]) for s in sig for r in rows if r["metric"] == "owner_frr_single_round" and r["sigma_m"] == s]
median = [float(r["percent"]) for s in sig for r in rows if r["metric"] == "owner_frr_median_of_5" and r["sigma_m"] == s]

fig, ax = plt.subplots(figsize=(6, 3.4), dpi=200)
x = range(3)
w = 0.36
b1 = ax.bar([i - w / 2 - 0.01 for i in x], single, w, color=BLUE, label="Single ranging round")
b2 = ax.bar([i + w / 2 + 0.01 for i in x], median, w, color=ORANGE, label="Median of 5 rounds")
for bars in (b1, b2):
    for bar in bars:
        ax.annotate(f"{bar.get_height():.2f}%", (bar.get_x() + bar.get_width() / 2, bar.get_height()),
                    xytext=(0, 3), textcoords="offset points", ha="center", fontsize=8, color=TEXT)
ax.set_xticks(list(x), [f"σ = {float(s):.1f} m" for s in sig])
ax.set_ylabel("Owner wrongly refused (%)", color=TEXT2, fontsize=9)
ax.set_title("False rejection rate of the real owner", color=TEXT, fontsize=11, loc="left")
ax.legend(frameon=False, fontsize=8, labelcolor=TEXT)
style(ax)
fig.tight_layout()
fig.savefig(R / "frr_by_noise.png")
plt.close(fig)

h = list(csv.DictReader(open(R / "distance_histogram.csv")))
left = [float(r["bin_start_m"]) for r in h]
own = [int(r["owner_trials"]) for r in h]
rel = [int(r["relay_trials"]) for r in h]
fig, ax = plt.subplots(figsize=(6, 3.4), dpi=200)
ax.bar(left, own, width=0.1, align="edge", color=BLUE, label="Owner (0.5–1.5 m)")
ax.bar(left, rel, width=0.1, align="edge", color=ORANGE, label="Zero-delay relay (5 m link)")
ax.axvline(2.0, color=TEXT, linewidth=1.2, linestyle="--")
ax.text(2.1, max(own + rel) * 0.55, "unlock threshold 2 m", fontsize=8, color=TEXT)
ax.set_xlabel("UWB-measured distance (m), σ = 0.3 m", color=TEXT2, fontsize=9)
ax.set_ylabel("Trials", color=TEXT2, fontsize=9)
ax.set_title("Owner vs. relay attacker: measured distance", color=TEXT, fontsize=11, loc="left")
ax.legend(frameon=False, fontsize=8, labelcolor=TEXT, loc="upper center", bbox_to_anchor=(0.515, 1.0))
style(ax)
fig.tight_layout()
fig.savefig(R / "distance_distribution.png")
plt.close(fig)
print("Charts saved to", R)
